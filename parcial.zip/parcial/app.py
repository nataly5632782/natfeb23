from flask import Flask, render_template
app=Flask(__name__)
#localhost:500
@app.route('/')
def main():
    return render_template('dasboard.html',page='main')
@app.route('/bt1')
def bt1():
    return render_template('charts-apexcharts.html',page='login')
@app.route('/bt5')
def bt5():
    return render_template('dasboard.html',page='dashboard')
@app.route('/bt3')
def bt3():
    return render_template('charts-echarts.html',page='charts-echarts')
@app.route('/bt4')
def bt4():
    return render_template('charts-chartjs.html',page='chartjs')